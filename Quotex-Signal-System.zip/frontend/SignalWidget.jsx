import React, { useEffect, useState } from 'react'

export default function SignalWidget(){
  const [signals, setSignals] = useState([])

  useEffect(()=>{
    const ws = new WebSocket('ws://localhost:8000/ws/signals')
    ws.onopen = ()=> console.log('ws open')
    ws.onmessage = e => {
      try{
        const s = JSON.parse(e.data)
        setSignals(prev => [s, ...prev].slice(0,50))
      }catch(err){console.error(err)}
    }
    ws.onclose = ()=> console.log('ws closed')
    return ()=> ws.close()
  },[])

  return (
    <div style={{padding: '12px', fontFamily: 'sans-serif'}}>
      <h2>Live Signals</h2>
      <div>
        {signals.map((s, i)=> (
          <div key={i} style={{border:'1px solid #ddd', padding:'8px', marginBottom:'8px', borderRadius:6}}>
            <div><strong>{s.symbol}</strong> — {s.timeframe} — {s.signal}</div>
            <div style={{fontSize:12, color:'#666'}}>{s.reason} • conf: {s.confidence}</div>
            <div style={{fontSize:11, color:'#999'}}>{s.timestamp}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
