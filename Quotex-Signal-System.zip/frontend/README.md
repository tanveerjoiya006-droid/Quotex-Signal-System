Frontend stub instructions
-------------------------
This is a minimal React stub. To develop the frontend:
1. `cd frontend`
2. `npm init -y`
3. `npm install react react-dom`
4. create a bundler (vite/create-react-app) or use a simple static site serving approach.
The frontend should connect to the backend websocket at ws://localhost:8000/ws/signals
