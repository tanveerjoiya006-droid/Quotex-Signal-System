This folder is for trained models. The starter does not include a trained model. Train with `python src/train.py` and models will be saved here.
