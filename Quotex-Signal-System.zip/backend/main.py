from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
import json

app = FastAPI()
clients = set()

class Signal(BaseModel):
    symbol: str
    timeframe: str
    timestamp: str
    signal: str
    confidence: float = 0.5
    reason: str | None = None
    expiry_seconds: int | None = 60

@app.post('/api/signal')
async def post_signal(sig: Signal):
    payload = sig.dict()
    data = json.dumps(payload)
    await broadcast(data)
    return {"status":"ok"}

async def broadcast(message: str):
    to_remove = []
    for ws in list(clients):
        try:
            await ws.send_text(message)
        except Exception:
            to_remove.append(ws)
    for r in to_remove:
        clients.remove(r)

@app.websocket('/ws/signals')
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    clients.add(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        clients.remove(websocket)
