import pandas as pd
import numpy as np

def rsi(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0).rolling(window=period).mean()
    down = -delta.clip(upper=0).rolling(window=period).mean()
    rs = up / (down + 1e-9)
    return 100 - (100 / (1 + rs))

def atr(df, period=14):
    high_low = df['high'] - df['low']
    high_close = (df['high'] - df['close'].shift()).abs()
    low_close = (df['low'] - df['close'].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def make_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df['return_1'] = df['close'].pct_change(1)
    df['return_3'] = df['close'].pct_change(3)
    df['sma_5'] = df['close'].rolling(5).mean()
    df['sma_20'] = df['close'].rolling(20).mean()
    df['ema_10'] = df['close'].ewm(span=10, adjust=False).mean()
    df['rsi_14'] = rsi(df['close'], 14)
    df['atr_14'] = atr(df, 14)
    df['sma5_slope'] = df['sma_5'].diff()
    df = df.dropna().reset_index(drop=True)
    return df
