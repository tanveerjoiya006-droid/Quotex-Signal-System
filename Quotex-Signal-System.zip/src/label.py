import numpy as np

def label_data(df, horizon=1, pct_threshold=0.002):
    df = df.copy()
    future_close = df['close'].shift(-horizon)
    ret = (future_close - df['close']) / df['close']
    df['target'] = (ret >= pct_threshold).astype(int)
    df = df.dropna().reset_index(drop=True)
    return df
