import pandas as pd
import joblib
import numpy as np
from src.features import make_features
from src.label import label_data
import os

MODEL_PATH = 'models/lgb_model.pkl'

if __name__ == '__main__':
    if not os.path.exists('data/market_features.csv'):
        print('ERROR: Place data/market_features.csv first')
        raise SystemExit(1)
    df = pd.read_csv('data/market_features.csv', parse_dates=['timestamp'])
    df = make_features(df)
    df = label_data(df, horizon=1, pct_threshold=0.002)
    model_pack = joblib.load(MODEL_PATH)
    models = model_pack['models']
    FEATURES = model_pack['features']
    threshold = model_pack['threshold']

    X = df[FEATURES].values
    probas = np.mean([m.predict(X) for m in models], axis=0)
    preds = (probas >= threshold).astype(int)

    df['pred'] = preds
    trades = df[df['pred']==1]
    wins = trades[trades['target']==1]
    precision = len(wins)/len(trades) if len(trades)>0 else 0
    print('trades', len(trades), 'wins', len(wins), 'precision', precision)
