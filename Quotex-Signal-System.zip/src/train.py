import pandas as pd
import lightgbm as lgb
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
import joblib
from src.features import make_features
from src.label import label_data
import os

DATA_PATH = 'data/market_features.csv'  # CSV by default
MODEL_PATH = 'models/lgb_model.pkl'

def ensure_dirs():
    os.makedirs('models', exist_ok=True)

if __name__ == '__main__':
    ensure_dirs()
    if not os.path.exists(DATA_PATH):
        print('ERROR: Put your OHLC historical data at', DATA_PATH)
        raise SystemExit(1)
    df = pd.read_csv(DATA_PATH, parse_dates=['timestamp'])
    df = make_features(df)
    df = label_data(df, horizon=1, pct_threshold=0.002)
    FEATURES = [c for c in df.columns if c not in ('timestamp','target')]
    X = df[FEATURES].values
    y = df['target'].values

    tscv = TimeSeriesSplit(n_splits=5)
    models = []
    val_probas = np.zeros(len(y))
    for train_idx, val_idx in tscv.split(X):
        X_train, X_val = X[train_idx], X[val_idx]
        y_train, y_val = y[train_idx], y[val_idx]
        dtrain = lgb.Dataset(X_train, label=y_train)
        params = {'objective':'binary','verbosity':-1,'learning_rate':0.05,'num_leaves':31}
        model = lgb.train(params, dtrain, num_boost_round=200)
        probas = model.predict(X_val)
        val_probas[val_idx] = probas
        models.append(model)

    from sklearn.metrics import precision_recall_curve
    p, r, t = precision_recall_curve(y, val_probas)
    candidates = [(th, pp, rr) for th, pp, rr in zip(t, p[:-1], r[:-1]) if pp >= 0.92]
    if candidates:
        chosen = min(candidates, key=lambda x: x[0])
        chosen_thresh = chosen[0]
    else:
        chosen_thresh = 0.99

    print('chosen_thresh', chosen_thresh)
    joblib.dump({'models': models, 'features': FEATURES, 'threshold': float(chosen_thresh)}, MODEL_PATH)
    print('model saved ->', MODEL_PATH)
